"""Recognize only the recorded manifest-path repair in historical source checks."""
import json
from pathlib import Path


def matches_frozen_sources(frozen, current):
    if frozen.keys() != current.keys():
        return False
    migration = json.loads((Path(__file__).parent / "research/card_quality_20261027/PORTABILITY.json").read_text())
    changes = migration["reader_changes"]
    return all(
        current[name] == old_hash
        or changes.get(name) == {"before_sha256": old_hash, "after_sha256": current[name]}
        for name, old_hash in frozen.items()
    )
