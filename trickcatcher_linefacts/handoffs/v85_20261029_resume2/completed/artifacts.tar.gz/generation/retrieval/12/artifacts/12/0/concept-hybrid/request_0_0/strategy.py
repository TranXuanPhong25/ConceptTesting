def strategy():
    return st.one_of(st.tuples(st.just([])), st.tuples(st.lists(st.text(), min_size=1, max_size=1)), st.tuples(st.lists(st.text(), min_size=2, max_size=2)))
