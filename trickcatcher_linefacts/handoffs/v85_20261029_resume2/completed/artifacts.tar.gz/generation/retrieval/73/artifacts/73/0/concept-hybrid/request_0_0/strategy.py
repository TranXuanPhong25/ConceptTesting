def strategy():
    return st.one_of(st.just([]), st.lists(st.integers(), min_size=1, max_size=1), st.lists(st.integers(), min_size=2, max_size=2))
