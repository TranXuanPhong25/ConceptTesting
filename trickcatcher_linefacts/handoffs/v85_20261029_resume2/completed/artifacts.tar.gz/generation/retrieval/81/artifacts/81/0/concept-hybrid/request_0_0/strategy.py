def strategy():
    return st.lists(st.floats(min_value=0.0, max_value=4.0, allow_nan=False, allow_infinity=False) | st.integers(min_value=0, max_value=4), min_size=0, max_size=100).map(lambda grades: (grades,))
