def strategy():
    return st.builds(lambda n, x, y: (n, x, y), n=st.integers(min_value=0, max_value=10 ** 18), x=st.integers(min_value=-10 ** 18, max_value=10 ** 18), y=st.integers(min_value=-10 ** 18, max_value=10 ** 18))
