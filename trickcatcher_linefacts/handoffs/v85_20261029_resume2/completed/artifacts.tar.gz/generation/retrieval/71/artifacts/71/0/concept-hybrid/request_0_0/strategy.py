def strategy():
    sides = st.floats(min_value=0.1, max_value=100.0)
    ab = st.tuples(sides, sides)
    epsilon = st.floats(min_value=0.0001, max_value=0.1)
    return st.builds(lambda a, b, c: (a, b, c), sides, sides, st.one_of(st.builds(lambda a, b: a + b, sides, sides), st.builds(lambda a, b, eps: a + b - eps, sides, sides, epsilon), st.builds(lambda a, b, eps: a + b + eps, sides, sides, epsilon)))
