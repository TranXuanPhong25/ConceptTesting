def strategy():
    return st.lists(st.integers(min_value=-99999, max_value=99999), min_size=0, max_size=20)
