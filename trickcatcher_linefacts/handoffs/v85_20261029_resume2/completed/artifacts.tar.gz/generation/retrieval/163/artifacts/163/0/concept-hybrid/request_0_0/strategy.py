def strategy():
    return st.tuples(st.integers(min_value=0, max_value=10), st.integers(min_value=0, max_value=10))
