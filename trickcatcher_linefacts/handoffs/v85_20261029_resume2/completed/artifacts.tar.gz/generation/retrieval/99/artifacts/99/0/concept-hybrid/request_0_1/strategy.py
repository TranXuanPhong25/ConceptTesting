def strategy():
    int_part = st.integers(min_value=0, max_value=10000)
    frac_options = st.sampled_from([0.5, 0.4999999999999999, 0.5000000000000001, 0.0])
    sign = st.sampled_from([1, -1])
    int_strategy = int_part.map(lambda x: str(x))
    decimal_strategy = st.builds(lambda i, f, s: str(s * i) if f == 0.0 else f'{s * i}.5' if f == 0.5 else f'{s * i}.4999999999999999' if f == 0.4999999999999999 else f'{s * i}.5000000000000001', int_part, frac_options, sign)
    return st.one_of(int_strategy, decimal_strategy)
