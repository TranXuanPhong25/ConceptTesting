def strategy():
    return st.integers(min_value=4, max_value=1000000).map(lambda n: (n,))
