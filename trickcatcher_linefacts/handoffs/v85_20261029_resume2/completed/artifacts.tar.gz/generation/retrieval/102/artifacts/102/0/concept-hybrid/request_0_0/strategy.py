def strategy():
    return st.tuples(st.integers(min_value=1, max_value=100), st.integers(min_value=1, max_value=100)).filter(lambda xy: xy[0] <= xy[1] and (xy[0] % 2 == 0 or xy[1] % 2 == 0))
