def strategy():
    return st.lists(st.integers(), min_size=1)
