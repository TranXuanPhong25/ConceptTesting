def strategy():
    return st.integers(min_value=-1000, max_value=1000).filter(lambda x: x in [-1, 0, 1]).map(lambda x: (x,))
