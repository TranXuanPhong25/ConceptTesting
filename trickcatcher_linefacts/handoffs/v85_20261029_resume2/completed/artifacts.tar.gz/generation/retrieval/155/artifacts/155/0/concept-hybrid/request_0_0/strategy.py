def strategy():
    return st.integers(min_value=-1000, max_value=1000).map(lambda x: (x,))
