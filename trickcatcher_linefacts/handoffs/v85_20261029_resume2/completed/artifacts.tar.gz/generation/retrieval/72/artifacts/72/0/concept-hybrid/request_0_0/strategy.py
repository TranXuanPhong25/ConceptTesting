def strategy():
    return st.tuples(st.lists(st.integers(min_value=0, max_value=10), min_size=0, max_size=2), st.integers(min_value=0, max_value=20))
