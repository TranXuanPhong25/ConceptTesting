def strategy():
    return st.tuples(st.integers(min_value=0, max_value=9).filter(lambda x: x % 11 == 0 or x % 13 == 0))
