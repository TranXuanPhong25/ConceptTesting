def strategy():
    return st.integers(min_value=2, max_value=100000).map(lambda n: (n,))
