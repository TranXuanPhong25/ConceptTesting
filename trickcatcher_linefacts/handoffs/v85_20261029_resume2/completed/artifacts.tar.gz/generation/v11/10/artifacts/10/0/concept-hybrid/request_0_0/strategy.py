def strategy():
    return st.builds(tuple, st.text(min_size=2, max_size=100).filter(lambda s: s[0] == s[-1]))
