def strategy():
    return st.text(alphabet=st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'), min_size=3, max_size=1000).map(lambda w: (w,))
