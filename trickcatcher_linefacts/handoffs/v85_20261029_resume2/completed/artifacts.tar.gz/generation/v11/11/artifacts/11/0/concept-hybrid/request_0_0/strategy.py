def strategy():
    binary_string = st.from_regex('[01]{0,1000}')
    return st.tuples(binary_string, binary_string)
