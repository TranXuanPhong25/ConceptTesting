def strategy():
    return st.tuples(st.lists(st.sampled_from(['(', ')']), min_size=1, max_size=10), st.lists(st.sampled_from(['(', ')']), min_size=1, max_size=10)).map(lambda x: [''.join(x[0]), ''.join(x[1])])
