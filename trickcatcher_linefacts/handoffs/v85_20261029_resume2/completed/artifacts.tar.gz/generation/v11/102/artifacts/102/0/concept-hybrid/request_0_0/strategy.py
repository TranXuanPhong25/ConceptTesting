def strategy():
    return st.tuples(st.integers(min_value=1, max_value=100), st.integers(min_value=1, max_value=100))
