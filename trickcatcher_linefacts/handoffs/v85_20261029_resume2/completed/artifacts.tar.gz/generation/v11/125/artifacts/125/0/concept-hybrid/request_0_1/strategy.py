def strategy():
    return st.tuples(st.text(min_size=1000, max_size=1000))
