def strategy():
    return st.tuples(st.text(max_size=1000))
