def strategy():
    return st.tuples(st.text(max_size=100, alphabet=st.characters(min_codepoint=0, max_codepoint=1114111)))
