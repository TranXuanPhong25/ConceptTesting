def strategy():
    grid = st.lists(st.lists(st.integers(min_value=0, max_value=1), min_size=1, max_size=100), min_size=1, max_size=100)
    capacity = st.integers(min_value=1, max_value=10)
    return st.tuples(grid, capacity)
