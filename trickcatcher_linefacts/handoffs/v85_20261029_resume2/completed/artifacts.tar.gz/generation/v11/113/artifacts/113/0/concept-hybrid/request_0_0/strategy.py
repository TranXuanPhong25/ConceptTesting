def strategy():
    digit_string = st.text(alphabet='0123456789', min_size=1, max_size=1000)
    return st.lists(digit_string, min_size=1, max_size=1000)
