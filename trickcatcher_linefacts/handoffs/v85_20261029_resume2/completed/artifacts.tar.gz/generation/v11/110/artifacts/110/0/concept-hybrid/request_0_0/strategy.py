def strategy():
    return st.tuples(st.lists(st.integers(), min_size=1, max_size=10), st.lists(st.integers(), min_size=1, max_size=10)).filter(lambda x: len(x[0]) != len(x[1]))
