def strategy():
    valid_date_str = st.builds(lambda m, d, y: f'{m:02d}-{d:02d}-{y:04d}', st.integers(min_value=1, max_value=12), st.integers(min_value=1, max_value=31), st.integers(min_value=1, max_value=9999))
    four_part_malformed = st.builds(lambda a, b, c, d: f'{a}-{b}-{c}-{d}', st.text(min_size=1, max_size=2), st.text(min_size=1, max_size=2), st.text(min_size=1, max_size=2), st.text(min_size=1, max_size=2))
    other_malformed = st.one_of(st.text(min_size=0, max_size=20), st.from_regex('^\\d{1,2}/\\d{1,2}/\\d{4}$'), st.from_regex('^\\d{1,2}-\\d{1,2}-\\d{1,3}$'), st.from_regex('^\\d{1,2}-\\d{1,2}-\\d{5,}$'), st.from_regex('^\\d{3,}-\\d{1,2}-\\d{4}$'), st.from_regex('^\\d{1,2}-\\d{3,}-\\d{4}$'), st.just(''))
    return st.one_of(valid_date_str, four_part_malformed, other_malformed)
