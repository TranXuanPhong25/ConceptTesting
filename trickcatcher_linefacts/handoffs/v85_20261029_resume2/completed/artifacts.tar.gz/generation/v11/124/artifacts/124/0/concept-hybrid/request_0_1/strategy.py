def strategy():
    day_zero = st.builds(lambda m, y: f'{m:02d}-00-{y:04d}', st.integers(min_value=1, max_value=12), st.integers(min_value=1900, max_value=2020))
    day_32 = st.builds(lambda m, y: f'{m:02d}-32-{y:04d}', st.integers(min_value=1, max_value=12), st.integers(min_value=1900, max_value=2020))
