def strategy():
    return st.text(min_size=1000, max_size=1000).map(lambda s: (s,))
