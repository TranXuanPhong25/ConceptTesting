def strategy():
    return st.text(max_size=1000).map(lambda s: (s,))
