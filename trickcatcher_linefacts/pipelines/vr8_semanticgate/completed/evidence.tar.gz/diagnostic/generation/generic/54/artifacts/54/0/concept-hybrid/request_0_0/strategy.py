def strategy():
    return st.tuples(st.text(st.characters(blacklist_categories=('Cs',), min_codepoint=32)), st.text(st.characters(blacklist_categories=('Cs',), min_codepoint=32)))
