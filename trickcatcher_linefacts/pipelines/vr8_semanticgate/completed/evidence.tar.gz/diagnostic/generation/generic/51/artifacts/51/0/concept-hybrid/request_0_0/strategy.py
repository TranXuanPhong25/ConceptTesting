def strategy():
    return st.text(st.characters(blacklist_characters='aeiouAEIOU', min_codepoint=32), min_size=1)
