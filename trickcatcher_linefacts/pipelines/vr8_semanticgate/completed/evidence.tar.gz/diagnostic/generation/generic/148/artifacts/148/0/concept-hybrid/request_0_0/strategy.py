def strategy():
    planets = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune']
    planet1 = st.sampled_from(planets)
    planet2 = st.sampled_from(planets)
    invalid_planet = st.text(min_size=1, max_size=20).filter(lambda s: s not in planets)
    return st.one_of(st.tuples(planet1, planet2), st.tuples(invalid_planet, planet1), st.tuples(planet1, invalid_planet), st.tuples(invalid_planet, invalid_planet))
