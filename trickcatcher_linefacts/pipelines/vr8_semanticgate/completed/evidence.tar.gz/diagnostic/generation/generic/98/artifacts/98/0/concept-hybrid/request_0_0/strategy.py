def strategy():
    return st.builds(tuple, st.text(alphabet='AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz', min_size=0, max_size=20))
