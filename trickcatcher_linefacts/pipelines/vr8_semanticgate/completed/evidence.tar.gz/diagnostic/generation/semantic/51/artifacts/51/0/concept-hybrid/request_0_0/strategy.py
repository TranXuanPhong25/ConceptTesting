def strategy():
    return st.text(alphabet=st.sampled_from('aeiouAEIOUbcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ0123456789 \t\n'))
