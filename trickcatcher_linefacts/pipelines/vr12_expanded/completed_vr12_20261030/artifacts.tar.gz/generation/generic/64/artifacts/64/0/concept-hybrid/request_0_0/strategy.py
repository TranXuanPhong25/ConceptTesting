def strategy():
    return st.text(alphabet=st.sampled_from('aeiouyAEIOUYbcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'), min_size=1, max_size=20)
