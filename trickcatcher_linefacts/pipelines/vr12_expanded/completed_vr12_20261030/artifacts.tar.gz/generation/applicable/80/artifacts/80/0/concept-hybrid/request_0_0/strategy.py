def strategy():
    return st.lists(st.sampled_from('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), min_size=3, max_size=100).map(lambda x: ''.join(x))
