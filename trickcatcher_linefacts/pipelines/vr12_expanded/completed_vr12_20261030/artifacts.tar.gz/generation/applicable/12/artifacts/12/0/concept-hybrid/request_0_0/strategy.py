def strategy():
    return st.lists(st.text(), min_size=1, max_size=10, unique_by=lambda s: s.lower())
