def strategy():
    return st.text(alphabet=st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'), min_size=0, max_size=100).map(lambda w: (w,))
