def strategy():
    return st.text(st.characters(blank_text=False, min_codepoint=32), min_size=2, max_size=20)
