def strategy():
    return st.tuples(st.text(alphabet=st.characters(blacklist_categories=('Cs',), min_codepoint=32), min_size=1, max_size=50), st.integers(min_value=-100, max_value=200))
