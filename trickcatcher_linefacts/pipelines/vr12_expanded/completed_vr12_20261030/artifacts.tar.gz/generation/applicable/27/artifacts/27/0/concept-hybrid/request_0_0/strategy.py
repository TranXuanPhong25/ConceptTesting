def strategy():
    return st.tuples(st.text(st.characters(blacklist_characters='\n\r\t')))
