def strategy():
    return st.tuples(st.text(st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'Zs', 'Zl', 'Zp', 'Cc', 'Cf'), blacklist_characters='', min_codepoint=0, max_codepoint=127), min_size=0, max_size=100))
