def strategy():
    return st.tuples(st.text(alphabet=st.characters(min_codepoint=0, max_codepoint=127), min_size=0, max_size=50), st.text(alphabet=st.characters(min_codepoint=0, max_codepoint=127), min_size=0, max_size=50))
