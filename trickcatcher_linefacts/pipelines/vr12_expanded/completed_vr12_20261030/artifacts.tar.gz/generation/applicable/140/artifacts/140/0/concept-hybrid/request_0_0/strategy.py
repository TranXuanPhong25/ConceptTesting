def strategy():
    return st.builds(lambda s: s, st.from_regex('^[a-zA-Z0-9_ ]*$', fullmatch=True)).filter(lambda s: ' ' in s)
