def strategy():
    return st.tuples(st.text(alphabet=st.sampled_from('aeiouAEIOUyYbcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ0123456789'), min_size=0, max_size=20))
